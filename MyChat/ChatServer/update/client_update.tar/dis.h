#ifndef _DIS_H_
#define _DIS_H_

#define NONE         "\033[m" 
#define RED          "\033[0;32;31m" 
#define LIGHT_RED    "\033[1;31m" 
#define UNDER_LINE   "\033[4m"
#define PURPLE       "\033[0;35m" 
#define GREEN        "\033[0;32;32m" 
#define DARK         "\033[30m" 
#define LAST         "\033[30;1H"
#define BLUE         "\033[0;32;34m"
#define YELLOW       "\033[1;33m"


#endif
